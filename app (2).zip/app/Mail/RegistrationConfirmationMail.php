<?php

namespace App\Mail;

use App\Models\EventRegistration;
use App\Models\Setting;
use App\Services\TicketService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class RegistrationConfirmationMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public function __construct(
        public readonly EventRegistration $registration,
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Registration Confirmed – ' . $this->registration->event?->title,
        );
    }

    public function content(): Content
    {
        $registration = $this->registration;
        $registration->loadMissing(['event', 'ticket', 'attendees', 'invoice']);

        $generalSettings  = Setting::getGroup('general');
        $siteName         = $generalSettings['site_name'] ?? 'Takaful Events';
        $contactEmail     = $generalSettings['contact_email'] ?? null;

        // Build ticket download URLs — one per attendee
        $ticketService = app(TicketService::class);
        $ticketUrls    = [];

        foreach ($registration->attendees as $attendee) {
            $ticketUrls[$attendee->attendee_no] = route('tickets.download', [
                'registration' => $registration->id,
                'attendee_no'  => $attendee->attendee_no,
            ]);
        }

        // Primary ticket download URL (first attendee or attendee #1)
        $primaryTicketUrl = $ticketUrls[1] ?? ($ticketUrls ? reset($ticketUrls) : '#');

        // Invoice download URL (if invoice exists)
        $invoiceUrl = null;
        if ($registration->invoice?->invoice_number) {
            $invoiceUrl = route('invoices.download', $registration->invoice->invoice_number);
        }

        // Generate QR CIDs for each attendee (for inline embedding)
        $qrCids = [];
        foreach ($registration->attendees as $attendee) {
            $qrCids[$attendee->attendee_no] = "qr-{$registration->id}-{$attendee->attendee_no}@takaful4all";
        }

        return new Content(
            view: 'emails.ticket-confirmation',
            with: [
                'registration' => $registration,
                'ticketUrl'    => $primaryTicketUrl,
                'ticketUrls'   => $ticketUrls,
                'invoiceUrl'   => $invoiceUrl,
                'siteName'     => $siteName,
                'contactEmail' => $contactEmail,
                'qrCids'       => $qrCids,
            ],
        );
    }

    /**
     * Attach inline QR codes as CID attachments for each attendee.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        $registration = $this->registration;
        $registration->loadMissing('attendees');

        $attachments = [];

        foreach ($registration->attendees as $attendee) {
            try {
                // Generate QR code payload (same as TicketService)
                $qrData = json_encode([
                    'ref'         => $registration->reference_no,
                    'attendee_no' => $attendee->attendee_no,
                ]);

                // Generate PNG QR code (NOT SVG — Outlook compatibility)
                $qrPng = QrCode::format('png')
                    ->size(300)
                    ->margin(0)
                    ->generate($qrData);

                // Build unique CID
                $cid = "qr-{$registration->id}-{$attendee->attendee_no}@takaful4all";

                // Attach as inline CID
                $attachments[] = Attachment::fromData(fn () => $qrPng, "qr-attendee-{$attendee->attendee_no}.png")
                    ->withMime('image/png')
                    ->inline()
                    ->as("qr-attendee-{$attendee->attendee_no}.png")
                    ->withContentId($cid);

            } catch (\Exception $e) {
                // Log error but continue with other attendees
                Log::error('Failed to generate QR code for attendee in email', [
                    'registration_id' => $registration->id,
                    'attendee_no'     => $attendee->attendee_no,
                    'error'           => $e->getMessage(),
                ]);
            }
        }

        return $attachments;
    }
}
