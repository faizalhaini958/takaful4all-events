<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use Inertia\Response;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): Response
    {
        return Inertia::render('Auth/Login', [
            'canResetPassword' => Route::has('password.request'),
            'status' => session('status'),
        ]);
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $request->session()->regenerate();

        // Honor a safe same-origin return_to param (e.g. from the registration auth gate)
        $returnTo = $request->input('return_to');
        if ($returnTo && is_string($returnTo) && preg_match('#^/[^/]#', $returnTo)) {
            return redirect($returnTo);
        }

        // Redirect admins to admin dashboard, regular users to user dashboard
        $redirectRoute = in_array($request->user()->role, ['admin', 'editor', 'checkin_staff'])
            ? route('admin.dashboard', absolute: false)
            : route('user.dashboard', absolute: false);

        return redirect()->intended($redirectRoute);
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
